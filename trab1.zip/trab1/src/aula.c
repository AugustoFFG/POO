#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../inc/aula.h"
#include "../inc/compromisso.h"

typedef struct aula{
    Compromisso* a;
    char disciplina[50];
    char grau[20];
}Aula;

Aula* RegistraAula(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int priodade_final, char* disciplina, char* grau){
    Aula* aula = malloc(sizeof(Aula));

    Compromisso* com = RegistraCompromisso(id, tipo, data, hora, duracao, prioridade, priodade_final);

    aula->a = com;

    snprintf(aula->disciplina, sizeof(aula->disciplina), "%s", disciplina);
    snprintf(aula->grau, sizeof(aula->grau), "%s", grau);

    return aula;
}

int AulaDuracao(Aula* aula){
    if (aula == NULL || aula->a == NULL) return 0;
    return CompromissoDuracao(aula->a);
}

void PrintaAula(Aula* aula){
    PrintaCompromisso(aula->a);
    printf("Disciplina: %s\n", aula->disciplina);
    printf("Grau: %s\n\n", aula->grau);
}

Compromisso* AulaGetCompromisso(Aula* aula) {
    return aula->a;
}

void PrintaAulaParaArquivo(FILE* arq, Aula* aula){
    fprintf(arq, "%s %s %s %s %d %d\n", CompromissoGetID(aula->a), CompromissoGetData(aula->a), CompromissoGetHora(aula->a), aula->disciplina, CompromissoGetDuracao(aula->a), CompromissoGetPrioridadeFinal(aula->a));
}
