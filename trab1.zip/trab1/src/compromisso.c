#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../inc/compromisso.h"

typedef struct compromisso{
    char id[10];
    char tipo;
    char data[11];
    char hora[6];
    int duracao; 
    int prioridade;  
    int prioridade_final;
} Compromisso;

Compromisso* CriaCompromisso(){
    Compromisso* com = (Compromisso*) malloc (sizeof(Compromisso));
    return com;
}

Compromisso* RegistraCompromisso(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final){

    Compromisso* com = CriaCompromisso();

    if(com == NULL){
        return NULL;
    }

    snprintf(com->id, sizeof(com->id), "%s", id);
    com->tipo = tipo;
    snprintf(com->data, sizeof(com->data), "%s", data);
    snprintf(com->hora, sizeof(com->hora), "%s", hora);
    com->duracao = duracao;
    com->prioridade = prioridade;
    com->prioridade_final = prioridade_final;

    return com;
}

int CompromissoDuracao(Compromisso* c){
    if (c == NULL) return 0;
    return c->duracao;
}

void PrintaCompromisso(Compromisso* com){
    if(com == NULL){
        printf("Compromisso nulo.\n");
        return;
    }
    printf("ID: %s\n", com->id);
    printf("Tipo: %c\n", com->tipo);
    printf("Data: %s\n", com->data);
    printf("Hora: %s\n", com->hora);
    printf("Duracao: %d minutos\n", com->duracao);
    printf("Prioridade: %d\n", com->prioridade);
    printf("Prioridade Final: %d\n", com->prioridade_final);
}

char* CompromissoGetID(Compromisso* c){ 
    return c->id; 
}

char* CompromissoGetData(Compromisso* c){ 
    return c->data; 
}

char* CompromissoGetHora(Compromisso* c){
    return c->hora; 
}

int CompromissoGetDuracao(Compromisso* c){ 
    return c->duracao; 
}

int CompromissoGetPrioridade(Compromisso* c){ 
    if (c == NULL) return 0;
    return c->prioridade; 
}

int CompromissoGetPrioridadeFinal(Compromisso* c){
    return c->prioridade_final; 
}

int HorarioParaMinutos(char* hora) {
    int h, m;
    sscanf(hora, "%d:%d", &h, &m);
    return h * 60 + m;
}

int ConflitoCompromissos(Compromisso* c1, Compromisso* c2) {
    if (c1 == NULL || c2 == NULL) return 0;

    // Se as datas forem diferentes, não há conflito
    if (strcmp(c1->data, c2->data) != 0)
        return 0;

    // Converter horários para minutos
    int inicio1 = HorarioParaMinutos(c1->hora);
    int fim1 = inicio1 + c1->duracao;

    int inicio2 = HorarioParaMinutos(c2->hora);
    int fim2 = inicio2 + c2->duracao;

    // Há conflito se os intervalos se sobrepõem
    if (inicio1 < fim2 && inicio2 < fim1)
        return 1;

    return 0;
}
