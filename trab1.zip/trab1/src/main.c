#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../inc/compromisso.h"
#include "../inc/leitura.h"
#include "../inc/lista.h"

int main(){
    Lista* compromissos = CriaLista(); 

    LerArquivo("agenda.txt", compromissos);

    printf("\n=== LISTA DE COMPROMISSOS ===\n");
    PrintaLista(compromissos);

    // CORRIGIDO: Agora passa apenas a lista de compromissos
    GerarRelatorios(compromissos);

    somarDuracoes("posicoes.txt", compromissos);

    // Liberar memória
    LiberaLista(compromissos);

    return 0;
}