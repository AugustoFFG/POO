#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../inc/pessoal.h"
#include "../inc/compromisso.h"

typedef struct pessoal{
    Compromisso* p;
    char adiavel[6];
    char motivo[50];
    char local[50];
} Pessoal;

Pessoal* RegistraPessoal(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* adiavel, char* motivo, char* local){
    Pessoal* pessoal = malloc(sizeof(Pessoal));

    Compromisso* com = RegistraCompromisso(id, tipo, data, hora, duracao, prioridade, prioridade_final);

    pessoal->p = com;

    snprintf(pessoal->adiavel, sizeof(pessoal->adiavel), "%s", adiavel);
    snprintf(pessoal->motivo, sizeof(pessoal->motivo), "%s", motivo);
    snprintf(pessoal->local, sizeof(pessoal->local), "%s", local);

    return pessoal;
}

int PessoalDuracao(Pessoal* pessoal){
    if (pessoal == NULL || pessoal->p == NULL) return 0;
    return CompromissoDuracao(pessoal->p);
}

void PrintaPessoal(Pessoal* pessoal){
    PrintaCompromisso(pessoal->p);
    printf("Adiavel: %s\n", pessoal->adiavel);
    printf("Motivo: %s\n", pessoal->motivo);
    printf("Local: %s\n\n", pessoal->local);
}

Compromisso* PessoalGetCompromisso(Pessoal* pessoal) {
    return pessoal->p;
}

int PessoalAdiavel(Pessoal* p) {
    if (strcmp(p->adiavel, "true") == 0)
        return 1;
    return 0;
}

void PrintaPessoalParaArquivo(FILE* arq, Pessoal* pessoal){
    fprintf(arq, "%s %s %s %s %d %d\n", CompromissoGetID(pessoal->p), CompromissoGetData(pessoal->p), CompromissoGetHora(pessoal->p), pessoal->motivo, CompromissoGetDuracao(pessoal->p), CompromissoGetPrioridadeFinal(pessoal->p));
}