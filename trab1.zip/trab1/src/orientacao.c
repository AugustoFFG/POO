#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../inc/orientacao.h"
#include "../inc/compromisso.h"

typedef struct orientacao{
    Compromisso* o;
    char adiavel[6];
    char orientando[50];
    char grau[20];
    char data_defesa[11];
    char hora_defesa[6];
} Orientacao;

Orientacao* RegistraOrientacao(char* id, char tipo, char* data, char* hora, int duracao, char* adiavel, char* orientando, char* grau, char* data_defesa, char* hora_defesa, int prioridade, int prioridade_final){
    Orientacao* orientacao = malloc(sizeof(Orientacao));

    Compromisso* com = RegistraCompromisso(id, tipo, data, hora, duracao, prioridade, prioridade_final);

    orientacao->o = com;

    snprintf(orientacao->adiavel, sizeof(orientacao->adiavel), "%s", adiavel);
    snprintf(orientacao->orientando, sizeof(orientacao->orientando), "%s", orientando);
    snprintf(orientacao->grau, sizeof(orientacao->grau), "%s", grau);
    snprintf(orientacao->data_defesa, sizeof(orientacao->data_defesa), "%s", data_defesa);
    snprintf(orientacao->hora_defesa, sizeof(orientacao->hora_defesa), "%s", hora_defesa);

    return orientacao;
}

int OrientacaoDuracao(Orientacao* orientacao){
    if (orientacao == NULL || orientacao->o == NULL) return 0;
    return CompromissoDuracao(orientacao->o);
}

void PrintaOrientacao(Orientacao* orientacao){
    PrintaCompromisso(orientacao->o);
    printf("Adiavel: %s\n", orientacao->adiavel);
    printf("Orientando: %s\n", orientacao->orientando);
    printf("Grau: %s\n", orientacao->grau);
    printf("Data da Defesa: %s\n", orientacao->data_defesa);
    printf("Hora da Defesa: %s\n\n", orientacao->hora_defesa);
}

Compromisso* OrientacaoGetCompromisso(Orientacao* orientacao) {
    return orientacao->o;
}

int OrientacaoAdiavel(Orientacao* o) {
    if (strcmp(o->adiavel, "true") == 0)
        return 1;
    return 0;
}

void PrintaOrientacaoParaArquivo(FILE* arq, Orientacao* orientacao){
    fprintf(arq, "%s %s %s %s %d %d\n", CompromissoGetID(orientacao->o), CompromissoGetData(orientacao->o), CompromissoGetHora(orientacao->o), orientacao->orientando, CompromissoGetDuracao(orientacao->o), CompromissoGetPrioridadeFinal(orientacao->o));
}