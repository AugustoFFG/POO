#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../inc/evento.h"
#include "../inc/compromisso.h"

typedef struct evento{
    Compromisso* e;
    char nome_evento[100];
    char local[50];
} Evento;

Evento* RegistraEvento(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* nome_evento, char* local){
    Evento* evento = malloc(sizeof(Evento));

    Compromisso* com = RegistraCompromisso(id, tipo, data, hora, duracao, prioridade, prioridade_final);

    evento->e = com;

    snprintf(evento->nome_evento, sizeof(evento->nome_evento), "%s", nome_evento);
    snprintf(evento->local, sizeof(evento->local), "%s", local);

    return evento;
}

int EventoDuracao(Evento* evento){
    if (evento == NULL || evento->e == NULL) return 0;
    return CompromissoDuracao(evento->e);
}

void PrintaEvento(Evento* evento){
    PrintaCompromisso(evento->e);
    printf("Nome do Evento: %s\n", evento->nome_evento);
    printf("Local: %s\n\n", evento->local);
}

Compromisso* EventoGetCompromisso(Evento* evento) {
    return evento->e;
}

void PrintaEventoParaArquivo(FILE* arq, Evento* evento){
    fprintf(arq, "%s %s %s %s %d %d\n", CompromissoGetID(evento->e), CompromissoGetData(evento->e), CompromissoGetHora(evento->e), evento->nome_evento, CompromissoGetDuracao(evento->e), CompromissoGetPrioridadeFinal(evento->e));
}