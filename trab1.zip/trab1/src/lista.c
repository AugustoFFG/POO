#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../inc/compromisso.h"
#include "../inc/aula.h"
#include "../inc/orientacao.h"
#include "../inc/reuniao.h"
#include "../inc/evento.h"
#include "../inc/pessoal.h"
#include "../inc/lista.h"

typedef struct no{
    char tipo;
    void* dado;
    int posicao;
    struct no* next;
} No;

typedef struct lista{
    No* head;
    int size;
} Lista;

// IMPLEMENTAÇÃO BÁSICA DA LISTA 

Lista* CriaLista(){
    Lista* lista = malloc(sizeof(Lista));
    lista->head = NULL;
    lista->size = 0;
    return lista;
}

void InsereNaLista(Lista* lista, void* dado, char tipo){
    if(lista == NULL) return;

    No* novoNo = (No*)malloc(sizeof(No));
    if(novoNo == NULL) return;

    novoNo->tipo = tipo;
    novoNo->dado = dado;
    novoNo->next = NULL;

    if(lista->head == NULL){
        lista->head = novoNo;
    } else{
        No* atual = lista->head;
        while(atual->next != NULL){
            atual = atual->next;
        }
        atual->next = novoNo;
    }
    lista->size++;
}

void PrintaLista(Lista* lista){
    if(lista == NULL) return;
    
    No* atual = lista->head;

    while(atual != NULL){
        switch (atual->tipo){
            case 'A':
                PrintaAula((Aula*) atual->dado);
                break;
            case 'O':
                PrintaOrientacao((Orientacao*) atual->dado);
                break;
            case 'R':
                PrintaReuniao((Reuniao*) atual->dado);
                break;
            case 'E':
                PrintaEvento((Evento*) atual->dado);
                break;
            case 'P':
                PrintaPessoal((Pessoal*) atual->dado);
                break;
            default:
                printf("Tipo desconhecido: %c\n", atual->tipo);
                break;
        }
        atual = atual->next;
    }

    printf("\nEND OF LIST\n");
}

void LiberaLista(Lista* lista){
    if(lista == NULL) return;
    
    No* atual = lista->head;
    while(atual != NULL){
        No* proximo = atual->next;
        
        switch (atual->tipo){
            case 'A':
                free((Aula*)atual->dado);
                break;
            case 'O':
                free((Orientacao*)atual->dado);
                break;
            case 'R':
                free((Reuniao*)atual->dado);
                break;
            case 'E':
                free((Evento*)atual->dado);
                break;
            case 'P':
                free((Pessoal*)atual->dado);
                break;
        }
        
        free(atual);
        atual = proximo;
    }
    
    free(lista);
}

// FUNÇÕES AUXILIARES 

//Função auxiliar para obter Compromisso de qualquer tipo
static Compromisso* GetCompromissoFromNo(No* no){
    if(no == NULL) return NULL;
    
    switch (no->tipo){
        case 'A': return AulaGetCompromisso((Aula*)no->dado);
        case 'O': return OrientacaoGetCompromisso((Orientacao*)no->dado);
        case 'R': return ReuniaoGetCompromisso((Reuniao*)no->dado);
        case 'E': return EventoGetCompromisso((Evento*)no->dado);
        case 'P': return PessoalGetCompromisso((Pessoal*)no->dado);
        default: return NULL;
    }
}

//Função auxiliar para verificar se compromisso é adiável
static int IsAdiavel(No* no){
    if(no == NULL) return 0;
    
    switch (no->tipo){
        case 'A': return 0; //Aulas não são adiáveis
        case 'O': return OrientacaoAdiavel((Orientacao*)no->dado);
        case 'R': return ReuniaoAdiavel((Reuniao*)no->dado);
        case 'E': return 0; //Eventos não são adiáveis
        case 'P': return PessoalAdiavel((Pessoal*)no->dado);
        default: return 0;
    }
}

// ALGORITMO MERGE SORT 

static No* Merge(No* a, No* b, int (*compare)(void*, void*)){
    if(a == NULL) return b;
    if(b == NULL) return a;

    if(compare(a, b) <= 0){
        a->next = Merge(a->next, b, compare);
        return a;
    } else{
        b->next = Merge(a, b->next, compare);
        return b;
    }
}

static void SplitList(No* source, No** front, No** back){
    if(source == NULL || source->next == NULL){
        *front = source;
        *back = NULL;
        return;
    }

    No* slow = source;
    No* fast = source->next;

    while(fast != NULL){
        fast = fast->next;
        if(fast != NULL){
            slow = slow->next;
            fast = fast->next;
        }
    }

    *front = source;
    *back = slow->next;
    slow->next = NULL;
}

static void MergeSort(No** headRef, int (*compare)(void*, void*)){
    No* head = *headRef;
    if(head == NULL || head->next == NULL) return;

    No* a;
    No* b;
    SplitList(head, &a, &b);

    MergeSort(&a, compare);
    MergeSort(&b, compare);

    *headRef = Merge(a, b, compare);
}

void OrdenaLista(Lista* lista, int (*compare)(void*, void*)){
    if(lista == NULL || lista->head == NULL || compare == NULL) return;
    MergeSort(&(lista->head), compare);
}

// FUNÇÕES DE COMPARAÇÃO 

int CompareDataHoraCrescente(void* a, void* b){
    No* noA = (No*)a;
    No* noB = (No*)b;

    Compromisso* compA = GetCompromissoFromNo(noA);
    Compromisso* compB = GetCompromissoFromNo(noB);

    if(compA == NULL || compB == NULL) return 0;

    //Primeiro compara data
    int dataCompare = strcmp(CompromissoGetData(compA), CompromissoGetData(compB));
    if(dataCompare != 0) return dataCompare;

    //Se mesma data, compara hora
    return strcmp(CompromissoGetHora(compA), CompromissoGetHora(compB));
}

int ComparePrioridadeDecrescente(void* a, void* b){
    No* noA = (No*)a;
    No* noB = (No*)b;

    Compromisso* compA = GetCompromissoFromNo(noA);
    Compromisso* compB = GetCompromissoFromNo(noB);

    if(compA == NULL || compB == NULL) return 0;

    int prioA = CompromissoGetPrioridadeFinal(compA);
    int prioB = CompromissoGetPrioridadeFinal(compB);

    //Ordem decrescente
    if(prioA > prioB) return -1;
    if(prioA < prioB) return 1;

    //Empate: compara por data/hora crescente
    return CompareDataHoraCrescente(a, b);
}

int CompareDuracaoCrescente(void* a, void* b){
    No* noA = (No*)a;
    No* noB = (No*)b;

    Compromisso* compA = GetCompromissoFromNo(noA);
    Compromisso* compB = GetCompromissoFromNo(noB);

    if(compA == NULL || compB == NULL) return 0;

    int durA = CompromissoGetDuracao(compA);
    int durB = CompromissoGetDuracao(compB);

    if(durA < durB) return -1;
    if(durA > durB) return 1;

    //Empate: compara por data/hora crescente
    return CompareDataHoraCrescente(a, b);
}

int CompareIdentificadorCrescente(void* a, void* b){
    No* noA = (No*)a;
    No* noB = (No*)b;

    Compromisso* compA = GetCompromissoFromNo(noA);
    Compromisso* compB = GetCompromissoFromNo(noB);

    if(compA == NULL || compB == NULL) return 0;

    return strcmp(CompromissoGetID(compA), CompromissoGetID(compB));
}

// FUNÇÃO DE CLASSIFICAÇÃO 

static int ClassificarCompromisso(No* atual, Lista* compromissos, char** idConflitante){
    Compromisso* c_atual = GetCompromissoFromNo(atual);
    if(c_atual == NULL) return 0;

    int maiorPrioridade = 1;
    *idConflitante = NULL;
    int maiorPrioridadeConflito = 0;

    No* outra = compromissos->head;
    while(outra != NULL){
        if(outra == atual){ 
            outra = outra->next; 
            continue; 
        }

        Compromisso* c_outra = GetCompromissoFromNo(outra);
        if(c_outra == NULL){
            outra = outra->next;
            continue;
        }

        if(ConflitoCompromissos(c_atual, c_outra)){
            printf("Conflito detectado entre %s e %s\n",
                   CompromissoGetID(c_atual),
                   CompromissoGetID(c_outra));
            
            int prio_atual = CompromissoGetPrioridadeFinal(c_atual);
            int prio_outra = CompromissoGetPrioridadeFinal(c_outra);
            
            if(prio_outra > prio_atual){
                maiorPrioridade = 0;
                if(prio_outra > maiorPrioridadeConflito){
                    maiorPrioridadeConflito = prio_outra;
                    *idConflitante = CompromissoGetID(c_outra);
                }
            }
        }

        outra = outra->next;
    }

    if(maiorPrioridade)
        return 1; //Confirmado

    //Verificar se é adiável
    int adiavel = IsAdiavel(atual);

    if(adiavel)
        return 2; //Adiado
    else
        return 0; //Cancelado
}

// FUNÇÕES DE IMPRESSÃO PARA ARQUIVO 

void ImprimirListaArquivo(Lista* lista, FILE* arq){
    if(!lista || !arq) return;

    No* n = lista->head;
    while(n){
        switch (n->tipo){
            case 'A': PrintaAulaParaArquivo(arq, (Aula*)n->dado); break;
            case 'O': PrintaOrientacaoParaArquivo(arq, (Orientacao*)n->dado); break;
            case 'R': PrintaReuniaoParaArquivo(arq, (Reuniao*)n->dado); break;
            case 'E': PrintaEventoParaArquivo(arq, (Evento*)n->dado); break;
            case 'P': PrintaPessoalParaArquivo(arq, (Pessoal*)n->dado); break;
        }
        fprintf(arq, "\n");
        n = n->next;
    }
}

// FUNÇÃO PRINCIPAL DE RELATÓRIOS 

void GerarRelatorios(Lista* compromissos){
    if(!compromissos){
        printf("Lista de compromissos vazia!\n");
        return;
    }

    printf("Classificando %d compromissos...\n", compromissos->size);

    //Criar listas para classificação
    Lista* confirmados = CriaLista();
    Lista* adiados = CriaLista();
    Lista* cancelados = CriaLista();
    Lista* todos = CriaLista();

    //Classificar compromissos
    No* atual = compromissos->head;
    int count = 0;
    
    while(atual != NULL){
        count++;
        char* idConflitante = NULL;
        int status = ClassificarCompromisso(atual, compromissos, &idConflitante);

        Compromisso* comp = GetCompromissoFromNo(atual);
        if(comp){
            printf("Compromisso %d: %s -> ", count, CompromissoGetID(comp));
            
            if(status == 1){
                printf("CONFIRMADO\n");
                InsereNaLista(confirmados, atual->dado, atual->tipo);
            } 
            
            else if(status == 2){
                printf("ADIADO (conflito com %s)\n", idConflitante ? idConflitante : "?");
                InsereNaLista(adiados, atual->dado, atual->tipo);
            } 
            
            else if(status == 0){
                printf("CANCELADO (conflito com %s)\n", idConflitante ? idConflitante : "?");
                InsereNaLista(cancelados, atual->dado, atual->tipo);
            }
            
            //Todos os compromissos vão para a lista 'todos'
            InsereNaLista(todos, atual->dado, atual->tipo);
        }

        atual = atual->next;
    }

    //Ordenar listas conforme especificação
    OrdenaLista(confirmados, CompareDataHoraCrescente);
    OrdenaLista(adiados, ComparePrioridadeDecrescente);
    OrdenaLista(cancelados, CompareDuracaoCrescente);
    OrdenaLista(todos, CompareIdentificadorCrescente);

    //Gerar arquivos de relatório
    FILE* arqConfirmados = fopen("relatconfirmados.txt", "w");
    FILE* arqAdiados = fopen("relatadiados.txt", "w");
    FILE* arqCancelados = fopen("relatcancelados.txt", "w");
    FILE* arqTodos = fopen("relatcompromissos.txt", "w");

    if(!arqConfirmados || !arqAdiados || !arqCancelados || !arqTodos){
        printf("Erro ao criar arquivos de relatório!\n");
        if(arqConfirmados) fclose(arqConfirmados);
        if(arqAdiados) fclose(arqAdiados);
        if(arqCancelados) fclose(arqCancelados);
        if(arqTodos) fclose(arqTodos);
        return;
    }

    printf("\nEstatísticas:\n");
    printf("Confirmados: %d\n", confirmados->size);
    printf("Adiados: %d\n", adiados->size);
    printf("Cancelados: %d\n", cancelados->size);
    printf("Total: %d\n", compromissos->size);

    //Escrever nos arquivos
    ImprimirListaArquivo(confirmados, arqConfirmados);
    ImprimirListaArquivo(adiados, arqAdiados);
    ImprimirListaArquivo(cancelados, arqCancelados);
    ImprimirListaArquivo(todos, arqTodos);

    fclose(arqConfirmados);
    fclose(arqAdiados);
    fclose(arqCancelados);
    fclose(arqTodos);

    //Liberar listas temporárias
    LiberaLista(confirmados);
    LiberaLista(adiados);
    LiberaLista(cancelados);
    LiberaLista(todos);

    printf("Relatórios gerados com sucesso!\n");
}

//FUNÇÃO SOMAR DURAÇÕES 

void somarDuracoes(const char* arquivo, Lista* lista){
    if(lista == NULL || lista->head == NULL){
        printf("Lista vazia ou inválida\n");
        return;
    }

    FILE* arq = fopen(arquivo, "r");
    if(!arq){
        printf("Erro ao abrir o arquivo de posições: %s\n", arquivo);
        return;
    }

    char linha[100];
    int totalMinutos = 0;

    while(fgets(linha, sizeof(linha), arq)){
        linha[strcspn(linha, "\r\n")] = '\0';  //remove \n e \r
        if(strlen(linha) == 0)
            continue;

        int pos = atoi(linha);
        if(pos <= 0){
            printf("Linha inválida no arquivo: %s (ignorada)\n", linha);
            continue;
        }

        //Navegar até a posição indicada
        No* atual = lista->head;
        int i = 1;
        while(atual != NULL && i < pos){
            atual = atual->next;
            i++;
        }

        if(atual == NULL){
            printf("Posição %d não encontrada na lista\n", pos);
            continue;
        }

        int dur = 0;
        switch (atual->tipo){
            case 'A':
                dur = AulaDuracao((Aula*) atual->dado);
                break;
            case 'O':
                dur = OrientacaoDuracao((Orientacao*) atual->dado);
                break;
            case 'R':
                dur = ReuniaoDuracao((Reuniao*) atual->dado);
                break;
            case 'E':
                dur = EventoDuracao((Evento*) atual->dado);
                break;
            case 'P':
                dur = PessoalDuracao((Pessoal*) atual->dado);
                break;
            default:
                printf("Tipo de compromisso desconhecido na posição %d\n", pos);
                continue;
        }

        //Se a duração for um número de 0 a 9, tratar como dia
        if(dur >= 0 && dur <= 9)
            dur *= 1440;

        totalMinutos += dur;
        printf("Posição %d: %d minutos\n", pos, dur);
    }

    fclose(arq);

    //Escrever resultado no arquivo
    FILE* resultado = fopen("resultado.txt", "w");
    if(resultado){
        fprintf(resultado, "%d\n", totalMinutos);
        fclose(resultado);
    }

    //Exibe resultado total
    printf("\nSoma total das durações: %d minutos", totalMinutos);
    printf("  (%d horas e %d minutos)\n\n", totalMinutos / 60, totalMinutos % 60);
}