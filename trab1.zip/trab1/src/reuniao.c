#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../inc/reuniao.h"
#include "../inc/compromisso.h"

typedef struct reuniao{
    Compromisso* a;
    char adiavel[6];
    char assunto[50];
}Reniao;

Reuniao* RegistraReuniao(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* adiavel, char* assunto){
    Reuniao* reuniao = (Reuniao*) malloc (sizeof(Reuniao));
    if(reuniao == NULL){
        return NULL;
    }

    reuniao->a = RegistraCompromisso(id, tipo, data, hora, duracao, prioridade, prioridade_final);
    snprintf(reuniao->adiavel, sizeof(reuniao->adiavel), "%s", adiavel);
    snprintf(reuniao->assunto, sizeof(reuniao->assunto), "%s", assunto);

    return reuniao;
}

int ReuniaoDuracao(Reuniao* reuniao){
    if (reuniao == NULL || reuniao->a == NULL) return 0;
    return CompromissoDuracao(reuniao->a);
}

void PrintaReuniao(Reuniao* reuniao){
    PrintaCompromisso(reuniao->a);
    printf("Adiavel: %s\n", reuniao->adiavel);
    printf("Assunto: %s\n\n", reuniao->assunto);
}

Compromisso* ReuniaoGetCompromisso(Reuniao* reuniao) {
    return reuniao->a;
}

int ReuniaoAdiavel(Reuniao* r) {
    if (strcmp(r->adiavel, "true") == 0)
        return 1;
    return 0;
}

void PrintaReuniaoParaArquivo(FILE* arq, Reuniao* reuniao){
    fprintf(arq, "%s %s %s %s %d %d\n", CompromissoGetID(reuniao->a), CompromissoGetData(reuniao->a), CompromissoGetHora(reuniao->a), reuniao->assunto, CompromissoGetDuracao(reuniao->a), CompromissoGetPrioridadeFinal(reuniao->a));
} 