#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../inc/leitura.h"
#include "../inc/compromisso.h"
#include "../inc/aula.h"
#include "../inc/orientacao.h"
#include "../inc/reuniao.h"
#include "../inc/evento.h"
#include "../inc/pessoal.h"
#include "../inc/lista.h"



#define MAX_LINHA 128

Aula* LerAula(char* linha, FILE* arq){
    char ID[10] = {0};         
    char tipo;                                
    char data[11] = {0};          
    char hora[6] = {0};             
    int duracao = 0;
    char disciplina[50] = {0};
    char grau[20] = {0};        
    int prioridade = 0;
    int prioridade_final = 0;
    int multiplicador = 2;

    //id
    strcpy(ID, &linha[0]);
    ID[strcspn(ID, "\r\n")] = 0;
    tipo = ID[0];

    // data e hora 
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    sscanf(linha, "%10s %5s", data, hora);

    // duracao
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    duracao = atoi(linha);

    // disciplina
    if(!fgets(disciplina, sizeof(disciplina), arq)) return NULL;
    disciplina[strcspn(disciplina, "\r\n")] = 0;

    // grau
    if(!fgets(grau, sizeof(grau), arq)) return NULL;
    grau[strcspn(grau, "\r\n")] = 0;

    // prioridade
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    prioridade = atoi(linha);
    prioridade_final = multiplicador * prioridade;

    // Cria e retorna a estrutura Aula preenchida
    Aula* aula = RegistraAula(ID, tipo, data, hora, duracao, prioridade, prioridade_final, disciplina, grau);
    return aula;
}

Orientacao* LerOrientacao(char* linha, FILE* arq){
    char ID[10] = {0};         
    char tipo;                                
    char data[11] = {0};          
    char hora[6] = {0};             
    int duracao = 0;
    char adiavel[6] = {0};
    char orientando[50] = {0};
    char grau[20] = {0};        
    char data_defesa[11] = {0};
    char hora_defesa[6] = {0};
    int prioridade = 0;
    int prioridade_final = 0;
    int multiplicador = 1;

    //id
    strcpy(ID, &linha[0]);
    ID[strcspn(ID, "\r\n")] = 0;
    tipo = ID[0];

    // data e hora 
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    sscanf(linha, "%10s %5s", data, hora);

    // duracao
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    duracao = atoi(linha);

    // adiavel
    fgets(linha, sizeof(linha), arq);
    linha[strcspn(linha, "\r\n")] = 0;
    strcpy(adiavel, linha);
    

    // orientando
    if(!fgets(orientando, sizeof(orientando), arq)) return NULL;
    orientando[strcspn(orientando, "\r\n")] = 0;

    // grau
    if(!fgets(grau, sizeof(grau), arq)) return NULL;
    grau[strcspn(grau, "\r\n")] = 0;

    // data_defesa
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    sscanf(linha, "%10s %5s", data_defesa, hora_defesa);
  

    // prioridade
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    prioridade = atoi(linha);

    if(strcmp(adiavel, "false") == 0){
        multiplicador += 1;    
    }

    prioridade_final = multiplicador * prioridade;

    // Cria e retorna a estrutura Orientacao preenchida
    Orientacao* orientacao = RegistraOrientacao(ID, tipo, data, hora, duracao, adiavel, orientando, grau, data_defesa, hora_defesa, prioridade, prioridade_final);
    
    return orientacao;
}

Reuniao* LerReuniao(char* linha, FILE* arq){
    char ID[10] = {0};         
    char tipo;                                
    char data[11] = {0};          
    char hora[6] = {0};             
    int duracao = 0;
    char adiavel[6] = {0};
    char assunto[50] = {0};        
    int prioridade = 0;
    int prioridade_final = 0;
    int multiplicador = 4;

    //id
    strcpy(ID, &linha[0]);
    ID[strcspn(ID, "\r\n")] = 0;
    tipo = ID[0];

    // data e hora 
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    sscanf(linha, "%10s %5s", data, hora);

    // duracao
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    duracao = atoi(linha);

    // adiavel
    fgets(linha, sizeof(linha), arq);
    linha[strcspn(linha, "\r\n")] = 0;
    strcpy(adiavel, linha);

    // assunto
    if(!fgets(assunto, sizeof(assunto), arq)) return NULL;
    assunto[strcspn(assunto, "\r\n")] = 0;

    // prioridade
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    prioridade = atoi(linha);

    if(strcmp(adiavel, "false") == 0){
        multiplicador += 1;    
    }

    prioridade_final = multiplicador * prioridade;

    // Cria e retorna a estrutura Reuniao preenchida
    Reuniao* reuniao = RegistraReuniao(ID, tipo, data, hora, duracao, prioridade, prioridade_final, adiavel, assunto);
    return reuniao;
}

Evento* LerEvento(char* linha, FILE* arq){
    char ID[10] = {0};         
    char tipo;                                
    char data[11] = {0};          
    char hora[6] = {0};             
    int duracao = 0;
    char nome_evento[100] = {0};        
    char local[50] = {0};
    int prioridade = 0;
    int prioridade_final = 0;
    int multiplicador = 3;

    //id
    strcpy(ID, &linha[0]);
    ID[strcspn(ID, "\r\n")] = 0;
    tipo = ID[0];

    // data e hora 
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    sscanf(linha, "%10s %5s", data, hora);

    // duracao
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    duracao = atoi(linha);

    // nome_evento
    if(!fgets(nome_evento, sizeof(nome_evento), arq)) return NULL;
    nome_evento[strcspn(nome_evento, "\r\n")] = 0;

    // local
    if(!fgets(local, sizeof(local), arq)) return NULL;
    local[strcspn(local, "\r\n")] = 0;

    // prioridade
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    prioridade = atoi(linha);
    prioridade_final = multiplicador * prioridade;

    // Cria e retorna a estrutura Evento preenchida
    Evento* evento = RegistraEvento(ID, tipo, data, hora, duracao, prioridade, prioridade_final, nome_evento, local);
    return evento;
}

Pessoal* LerPessoal(char* linha, FILE* arq){
    char ID[10] = {0};         
    char tipo;                                
    char data[11] = {0};          
    char hora[6] = {0};             
    int duracao = 0;
    char adiavel[6] = {0};
    char motivo[50] = {0};
    char local[50] = {0};        
    int prioridade = 0;
    int prioridade_final = 0;
    int multiplicador = 2;

    //id
    strcpy(ID, &linha[0]);
    ID[strcspn(ID, "\r\n")] = 0;
    tipo = ID[0];

    // data e hora 
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    sscanf(linha, "%10s %5s", data, hora);

    // duracao
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    duracao = atoi(linha);

    // adiavel
    fgets(linha, sizeof(linha), arq);
    linha[strcspn(linha, "\r\n")] = 0;
    strcpy(adiavel, linha);

    // motivo
    if(!fgets(motivo, sizeof(motivo), arq)) return NULL;
    motivo[strcspn(motivo, "\r\n")] = 0;

    // local
    if(!fgets(local, sizeof(local), arq)) return NULL;
    local[strcspn(local, "\r\n")] = 0;

    // prioridade
    if(!fgets(linha, MAX_LINHA, arq)) return NULL;
    linha[strcspn(linha, "\r\n")] = 0;
    prioridade = atoi(linha);

    if(strcmp(adiavel, "false") == 0){
        multiplicador += 1;    
    }

    prioridade_final = multiplicador * prioridade;

    // Cria e retorna a estrutura Pessoal preenchida
    Pessoal* pessoal = RegistraPessoal(ID, tipo, data, hora, duracao, prioridade, prioridade_final, adiavel, motivo, local);
    return pessoal;
}

int LerArquivo(char* arquivo, Lista* lista){
    FILE* file = fopen(arquivo, "r");
    if(file == NULL){
        printf("Erro ao abrir o arquivo %s\n", arquivo);
        return -1;
    }

    char linha[MAX_LINHA];
    while(fgets(linha, sizeof(linha), file)){
        linha[strcspn(linha, "\r\n")] = 0;
        
        if (strlen(linha) == 0){
            continue;
        }

        if(linha[0] != '\n'){
            switch(linha[0]){
                case 'A':{
                    Aula* a = LerAula(linha, file);
                    if(a != NULL) {
                        InsereNaLista(lista, a, 'A');
                    }
                } break;

                case 'O':{
                    Orientacao* o = LerOrientacao(linha, file);
                    if(o != NULL) {
                        InsereNaLista(lista, o, 'O');
                    }
                } break;
                
                case 'R':{
                    Reuniao* r = LerReuniao(linha, file);
                    if(r != NULL) {
                        InsereNaLista(lista, r, 'R');
                    }
                } break;

                case 'E':{
                    Evento* e = LerEvento(linha, file);
                    if(e != NULL) {
                        InsereNaLista(lista, e, 'E');
                    } 
                } break;
                case 'P':{
                    Pessoal* p = LerPessoal(linha, file);
                    if(p != NULL) {
                        InsereNaLista(lista, p, 'P');
                    }
                } break;
                
                default:
                    printf("Tipo de compromisso desconhecido: %c\n", linha[0]);
                    break;
            }
        }
    }

    fclose(file);
    return 0;
}