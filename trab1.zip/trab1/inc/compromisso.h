#ifndef COMPROMISSO_H
#define COMPROMISSO_H

#include <stdio.h>

typedef struct compromisso Compromisso;

Compromisso* CriaCompromisso();
Compromisso* RegistraCompromisso(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final);
int CompromissoDuracao(Compromisso* c);
void PrintaCompromisso(Compromisso* com);
char* CompromissoGetID(Compromisso* c);
char* CompromissoGetData(Compromisso* c);
char* CompromissoGetHora(Compromisso* c);
int CompromissoGetDuracao(Compromisso* c);
int CompromissoGetPrioridade(Compromisso* c);
int CompromissoGetPrioridadeFinal(Compromisso* c);
int HorarioParaMinutos(char* hora);
int ConflitoCompromissos(Compromisso* c1, Compromisso* c2);

#endif