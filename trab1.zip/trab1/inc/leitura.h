#ifndef LEITURA_H
#define LEITURA_H

#include "aula.h"
#include "compromisso.h"
#include "orientacao.h"
#include "reuniao.h"
#include "evento.h"
#include "pessoal.h"
#include "lista.h"

Aula* LerAula(char* linha, FILE* arq);
Orientacao* LerOrientacao(char* linha, FILE* arq);
Reuniao* LerReuniao(char* linha, FILE* arq);
Evento* LerEvento(char* linha, FILE* arq);
Pessoal* LerPessoal(char* linha, FILE* arq);
int LerArquivo(char* arquivo, Lista* lista);
void somarDuracoes(const char* arquivo, Lista* lista);



#endif