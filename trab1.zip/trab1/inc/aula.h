#ifndef AULA_H
#define AULA_H

#include "../inc/compromisso.h"

typedef struct aula Aula;

Aula* RegistraAula(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* disciplina, char* grau);
int AulaDuracao(Aula* aula);
Compromisso* AulaGetCompromisso(Aula* aula);
void PrintaAula(Aula* aula);
void PrintaAulaParaArquivo(FILE* arq, Aula* aula);

#endif