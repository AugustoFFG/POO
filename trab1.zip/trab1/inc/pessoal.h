#ifndef PESSOAL_H
#define PESSOAL_H

#include "../inc/compromisso.h"

typedef struct pessoal Pessoal;

Pessoal* RegistraPessoal(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* adiavel, char* motivo, char* local);
int PessoalDuracao(Pessoal* pessoal);
Compromisso* PessoalGetCompromisso(Pessoal* pessoal);
int PessoalAdiavel(Pessoal* p);
void PrintaPessoal(Pessoal* pessoal);
void PrintaPessoalParaArquivo(FILE* arq, Pessoal* pessoal);

#endif