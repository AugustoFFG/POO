#ifndef ORIENTACAO_H
#define ORIENTACAO_H

#include "../inc/compromisso.h"

typedef struct orientacao Orientacao;

Orientacao* RegistraOrientacao(char* id, char tipo, char* data, char* hora, int duracao, char* adiavel, char* orientando, char* grau, char* data_defesa, char* hora_defesa, int prioridade, int prioridade_final);
int OrientacaoDuracao(Orientacao* orient);
Compromisso* OrientacaoGetCompromisso(Orientacao* orientacao);
int OrientacaoAdiavel(Orientacao* o); 
void PrintaOrientacao(Orientacao* orientacao);
void PrintaOrientacaoParaArquivo(FILE* arq, Orientacao* orientacao);

#endif