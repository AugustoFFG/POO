#ifndef REUNIAO_H
#define REUNIAO_H

#include "../inc/compromisso.h"

typedef struct reuniao Reuniao;

Reuniao* RegistraReuniao(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* disciplina, char* grau);
int ReuniaoDuracao(Reuniao* reuniao);
Compromisso* ReuniaoGetCompromisso(Reuniao* reuniao);
int ReuniaoAdiavel(Reuniao* r);
void PrintaReuniao(Reuniao* reuniao);
void PrintaReuniaoParaArquivo(FILE* arq, Reuniao* reuniao);

#endif