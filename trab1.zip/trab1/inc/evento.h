#ifndef EVENTO_H
#define EVENTO_H

#include "compromisso.h"

typedef struct evento Evento;

Evento* RegistraEvento(char* id, char tipo, char* data, char* hora, int duracao, int prioridade, int prioridade_final, char* nome_evento, char* local);
int EventoDuracao(Evento* evento);
Compromisso* EventoGetCompromisso(Evento* evento);
void PrintaEvento(Evento* evento);
void PrintaEventoParaArquivo(FILE* arq, Evento* evento);

#endif