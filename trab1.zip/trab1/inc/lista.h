#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "compromisso.h"

typedef struct no No;
typedef struct lista Lista;

Lista* CriaLista();
void InsereNaLista(Lista* lista, void* dado, char tipo);
void PrintaLista(Lista* lista);
void LiberaLista(Lista* lista);
void ImprimirListaArquivo(Lista* lista, FILE* arq);
void GerarRelatorios(Lista* compromissos);
void somarDuracoes(const char* arquivo, Lista* lista);


typedef int (*CompareFunction)(void*, void*);
void OrdenaLista(Lista* lista, CompareFunction compare);


int CompareDataHoraCrescente(void* a, void* b);
int ComparePrioridadeDecrescente(void* a, void* b);
int CompareDuracaoCrescente(void* a, void* b);
int CompareIdentificadorCrescente(void* a, void* b);

#endif